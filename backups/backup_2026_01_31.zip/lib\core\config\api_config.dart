class ApiConfig {
  static const String geminiApiKey = "AIzaSyB9PhkXejEfeNJvjCk8U6mnY4MelD-ejIM"; // User provided
}
